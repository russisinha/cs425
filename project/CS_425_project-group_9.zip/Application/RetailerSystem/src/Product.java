public class Product {
    String storeName;
    Integer storeId;
    String upc;
    String prodName;
    Float price;
    Integer tax;
    String brand;
    String vendor;
    String size;
    Integer quantity;

}
