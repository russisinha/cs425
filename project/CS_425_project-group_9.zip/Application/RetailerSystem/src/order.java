public class order {
    Integer orderid;
    String upc;
    String pName;
    Integer qty;
    Float amount;
    String date;
}
