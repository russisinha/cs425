import java.util.List;

public class User {
    String id;
    String f_name;
    String l_name;
    String email;
    String password;
    String street;
    String apt_num;
    String city;
    String state;
    String zip;
    String country;
    String phone;

    List<Product> cart;
    CreditCard cc_default;

}
