import java.util.Date;

public class CreditCard {
    String cc_name;
    String cc_numb;
    String cc_exp_date;
    String cc_cvv;
}
